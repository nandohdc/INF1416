package activity;

import javax.swing.*;

public class MainAdmin {

    public MainAdmin(){
        JPanel panel = new JPanel();
        JButton botaoCarregar = new JButton("Carregar XML");
    }

}
