package repository;

public class UserModel {
}
